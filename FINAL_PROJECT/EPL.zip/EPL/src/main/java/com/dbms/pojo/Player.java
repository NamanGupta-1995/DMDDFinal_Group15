package com.dbms.pojo;


public class Player {

	int PlayerID;
	
	int TeamID;

	public String PlayerName;

	int Age;

	String Nationality;

	String Position;

	int Assists_overall;

	int Assists_home;

	int Assists_away;

	int Penalty_goals;

	int Penalty_misses;

	int Yellow_cards_overall;

	int Red_cards_overall;

	String Dominant_leg;

	int Goals_overall;

	int Goals_home;

	int Goals_away;

	
	public int getPlayerID() {
		return PlayerID;
	}

	public void setPlayerID(int playerID) {
		PlayerID = playerID;
	}

	public int getTeamID() {
		return TeamID;
	}

	public void setTeamID(int teamID) {
		TeamID = teamID;
	}

	public String getPlayerName() {
		return PlayerName;
	}

	public void setPlayerName(String playerName) {
		PlayerName = playerName;
	}

	public int getAge() {
		return Age;
	}

	public void setAge(int age) {
		Age = age;
	}

	public String getNationality() {
		return Nationality;
	}

	public void setNationality(String nationality) {
		Nationality = nationality;
	}

	public String getPosition() {
		return Position;
	}

	public void setPosition(String position) {
		Position = position;
	}

	public int getAssists_overall() {
		return Assists_overall;
	}

	public void setAssists_overall(int assists_overall) {
		Assists_overall = assists_overall;
	}

	public int getAssists_home() {
		return Assists_home;
	}

	public void setAssists_home(int assists_home) {
		Assists_home = assists_home;
	}

	public int getAssists_away() {
		return Assists_away;
	}

	public void setAssists_away(int assists_away) {
		Assists_away = assists_away;
	}

	public int getPenalty_goals() {
		return Penalty_goals;
	}

	public void setPenalty_goals(int penalty_goals) {
		Penalty_goals = penalty_goals;
	}

	public int getPenalty_misses() {
		return Penalty_misses;
	}

	public void setPenalty_misses(int penalty_misses) {
		Penalty_misses = penalty_misses;
	}

	public int getYellow_cards_overall() {
		return Yellow_cards_overall;
	}

	public void setYellow_cards_overall(int yellow_cards_overall) {
		Yellow_cards_overall = yellow_cards_overall;
	}

	public int getRed_cards_overall() {
		return Red_cards_overall;
	}

	public void setRed_cards_overall(int red_cards_overall) {
		Red_cards_overall = red_cards_overall;
	}

	public String getDominant_leg() {
		return Dominant_leg;
	}

	public void setDominant_leg(String dominant_leg) {
		Dominant_leg = dominant_leg;
	}

	public int getGoals_overall() {
		return Goals_overall;
	}

	public void setGoals_overall(int goals_overall) {
		Goals_overall = goals_overall;
	}

	public int getGoals_home() {
		return Goals_home;
	}

	public void setGoals_home(int goals_home) {
		Goals_home = goals_home;
	}

	public int getGoals_away() {
		return Goals_away;
	}

	public void setGoals_away(int goals_away) {
		Goals_away = goals_away;
	}

}
