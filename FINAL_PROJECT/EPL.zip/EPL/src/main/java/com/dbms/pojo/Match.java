package com.dbms.pojo;
import java.util.Date;

public class Match {

	int CommitteeID ;

	int RefereeID  ;

	int VenueID  ;

	int TeamA  ;

	int TeamB ;

	int TeamA_Score ;

	int TeamB_Score  ;

	int Extra_Time  ; 

	Date MatchDate;

	public int getCommitteeID() {
		return CommitteeID;
	}

	public void setCommitteeID(int committeeID) {
		CommitteeID = committeeID;
	}

	public int getRefereeID() {
		return RefereeID;
	}

	public void setRefereeID(int refereeID) {
		RefereeID = refereeID;
	}

	public int getVenueID() {
		return VenueID;
	}

	public void setVenueID(int venueID) {
		VenueID = venueID;
	}

	public int getTeamA() {
		return TeamA;
	}

	public void setTeamA(int teamA) {
		TeamA = teamA;
	}

	public int getTeamB() {
		return TeamB;
	}

	public void setTeamB(int teamB) {
		TeamB = teamB;
	}

	public int getTeamA_Score() {
		return TeamA_Score;
	}

	public void setTeamA_Score(int teamA_Score) {
		TeamA_Score = teamA_Score;
	}

	public int getTeamB_Score() {
		return TeamB_Score;
	}

	public void setTeamB_Score(int teamB_Score) {
		TeamB_Score = teamB_Score;
	}

	public int getExtra_Time() {
		return Extra_Time;
	}

	public void setExtra_Time(int extra_Time) {
		Extra_Time = extra_Time;
	}

	public Date getMatchDate() {
		return MatchDate;
	}

	public void setMatchDate(Date matchDate) {
		MatchDate = matchDate;
	}
	
	
}
