package com.dbms.epl;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.dbms.dao.UserLoginDao;
import com.dbms.pojo.Player;

@Controller
public class MainController {

	@RequestMapping(value = "/epl.htm", method = RequestMethod.GET)
	public ModelAndView home(HttpServletRequest request) {
		
		return new ModelAndView("main");
		
	}
	
	@RequestMapping(value = "getData.htm", method = RequestMethod.POST)
	public ModelAndView action(UserLoginDao userdao, HttpServletRequest request, RedirectAttributes attributes) {
		
		//String choice = request.getParameter("eplTable");
		int match = Integer.parseInt(request.getParameter("match"));
		int player = Integer.parseInt(request.getParameter("player"));
		userdao.get(match,player);
		attributes.addFlashAttribute("success", "Goal Added!");
		attributes.addAttribute("message", "Success");
		//System.out.print(choice);
		return new ModelAndView("goal-success-view");
		
	}
	
	@RequestMapping(value = "/getPlayers.htm", method = RequestMethod.POST)
	public ModelAndView action1(UserLoginDao userdao, HttpServletRequest request, RedirectAttributes attributes) {
		
		HttpSession session = request.getSession(true);
        
		int choice = Integer.parseInt(request.getParameter("eplTable"));
		List<Player> listOfPlayer = userdao.getPlayer(choice);
		session.setAttribute("playerList", listOfPlayer);
		//request.setAttribute("playerList", listOfPlayer);
		attributes.addFlashAttribute("success", "Goal Added!");
		
		attributes.addAttribute("message", "Success");
		System.out.print(choice);
		return new ModelAndView("team-view");
		
	}
	
	@RequestMapping(value = "/updatePlayer.htm", method = RequestMethod.POST)
	public ModelAndView updatePlayer(UserLoginDao userdao, HttpServletRequest request, RedirectAttributes attributes) {
		
		HttpSession session = request.getSession(true);
        
		int choice = Integer.parseInt(request.getParameter("teamDD"));
		
		String player = request.getParameter("Playername");
				
		userdao.updatePlayer(choice, player);
		
		return new ModelAndView("main");
		
	}
	
}