package com.dbms.dao;

import java.sql.Date;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;

import com.dbms.dao.DAO;
import com.dbms.pojo.Goal;
import com.dbms.pojo.Player;

public class UserLoginDao extends DAO {

	public UserLoginDao() {
		System.out.println("*** User Login DAO");
	}
	
	public void get(int match, int player) {
		
		   DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");  
		   LocalDateTime now = LocalDateTime.now();  
		   //System.out.println(dtf.format(now));  
		   begin();
		   Goal goal = new Goal();
		   //goal.setGoalID(566);
		   goal.setMatchID(match);
		   goal.setPlayerID(player);
		   goal.setTime(dtf.format(now));
		   getSession().save(goal);
		   
		commit();

	}
	
	public List<Player> getPlayer(int teamID) {

		List<Object> adminlistobject = getSession().createSQLQuery("select * from Player where TeamID = " +teamID).addEntity(Player.class).list();
		List<Player> adminlist = new ArrayList<Player>(adminlistobject.size());
		for (Object object : adminlistobject) {
			adminlist.add((Player) object);
		}
		for(int i=0;i<adminlist.size();i++) {
			System.out.println(adminlist.get(i).getPlayerName());
		}
		return adminlist;
	}
	
	public void updatePlayer(int teamID, String playerName) {

		Query query = getSession().createSQLQuery("UPDATE Player SET TeamID =" + teamID + " WHERE PlayerName =" + playerName);
		query.executeUpdate();
		
	}
}
