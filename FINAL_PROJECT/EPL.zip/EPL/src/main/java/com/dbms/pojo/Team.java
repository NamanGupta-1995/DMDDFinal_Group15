package com.dbms.pojo;
public class Team {

	int VenueID;

	int Name;

	int Rank;

	String City;

	String Address;

	int Contact;

	public int getVenueID() {
		return VenueID;
	}

	public void setVenueID(int venueID) {
		VenueID = venueID;
	}

	public int getName() {
		return Name;
	}

	public void setName(int name) {
		Name = name;
	}

	public int getRank() {
		return Rank;
	}

	public void setRank(int rank) {
		Rank = rank;
	}

	public String getCity() {
		return City;
	}

	public void setCity(String city) {
		City = city;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public int getContact() {
		return Contact;
	}

	public void setContact(int contact) {
		Contact = contact;
	}
	
	
}
